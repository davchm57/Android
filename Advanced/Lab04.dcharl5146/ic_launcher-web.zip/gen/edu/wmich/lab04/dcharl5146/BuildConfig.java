/** Automatically generated file. DO NOT MODIFY */
package edu.wmich.lab04.dcharl5146;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}